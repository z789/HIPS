#!/bin/bash

# stop apptable_manager
pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		for i in {1..90};
		do
			# sudo kill -SIGTERM ${pid}
			sleep 1

			kill -0  ${pid} 2>/dev/null
			live=$?
			if [ ${live} -eq 1 ]; then
				echo "stop apptable_manager succ"
				break;
			elif [ ${i} -lt 90 ]; then
				echo "stopping apptable_manager ..."
			else
				echo "stop apptable_manager fail! You may be kill -9 ${pid}"
			fi
		done
	else
		echo "apptable_manager not aliveing"
	fi
else
	echo "apptable_manager not aliveing"
fi


# stop apptable
pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		for i in {1..90};
		do
			# sudo kill -SIGTERM ${pid}
			sleep 1

			kill -0  ${pid} 2>/dev/null
			live=$?
			if [ ${live} -eq 1 ]; then
				echo "stop apptable succ"
				break;
			elif [ ${i} -lt 90 ]; then
				echo "stopping apptable ..."
			else
				echo "stop apptable fail! You may be kill -9 ${pid}"
			fi
		done
	else
		echo "apptable not aliveing"
	fi
else
	echo "apptable not aliveing"
fi
