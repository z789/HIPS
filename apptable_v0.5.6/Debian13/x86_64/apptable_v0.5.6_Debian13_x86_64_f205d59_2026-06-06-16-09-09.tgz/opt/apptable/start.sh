#!/bin/bash
 
DIR_INSTALL="/opt/apptable"
APPTABLE=${DIR_INSTALL}"/apptable"
APPTABLE_MANAGER=${DIR_INSTALL}"/apptable_manager"
DIR_APPTABLE_CONFIG=${DIR_INSTALL}"/config"
MK_USR_INTERL_NAME_LIST=${DIR_INSTALL}"/mk_usr_interp_name_list"

USR_CONFIG_FILE_LIST="${DIR_APPTABLE_CONFIG}/usr_block_hash_list ${DIR_APPTABLE_CONFIG}/usr_block_prog_list ${DIR_APPTABLE_CONFIG}/usr_block_url_list ${DIR_APPTABLE_CONFIG}/usr_block_ip_list ${DIR_APPTABLE_CONFIG}/usr_block_port_list ${DIR_APPTABLE_CONFIG}/usr_interp_name_list"

APPTABLE_MANAGER_LOG="/var/log/apptable_manager.log"
APPTABLE_LOG="/var/log/apptable.log"

pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "apptable is aliving. If you wish restart, use ./restart.sh" | tee -a ${APPTABLE_MANAGER_LOG}
		exit 0;
	fi
fi

pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "apptable_manager is aliving. If you wish restart, use ./restart.sh" | tee -a ${APPTABLE_MANAGER_LOG}
		exit 0;
	fi
fi

for FILE in ${USR_CONFIG_FILE_LIST}
do
	if [ ! -f ${FILE} ]; then
		touch ${FILE}
		chmod 640 ${FILE}
	fi 
done


sudo ${MK_USR_INTERL_NAME_LIST}

sudo ${APPTABLE}
sleep 0.5
pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
	echo "start apptable succ" | tee -a ${APPTABLE_MANAGER_LOG}
	fi
else
	echo "start apptable fail" | tee -a ${APPTABLE_MANAGER_LOG}
	exit 1;
fi

#MALLOC_ARENA_MAX=1 MALLOC_TRIM_THRESHOLD_=0 ${APPTABLE_MANAGER}
${APPTABLE_MANAGER}
sleep 0.5
pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "start apptable_manager succ" | tee -a ${APPTABLE_MANAGER_LOG}
	fi
else
	echo "start apptable_manager fail" | tee -a ${APPTABLE_MANAGER_LOG}
fi
