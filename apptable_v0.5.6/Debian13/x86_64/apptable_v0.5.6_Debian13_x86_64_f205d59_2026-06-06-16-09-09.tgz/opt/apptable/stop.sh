#!/bin/bash

APPTABLE_MANAGER_LOG="/var/log/apptable_manager.log"
APPTABLE_LOG="/var/log/apptable.log"
MAX_TIME_STOP=180

# stop apptable
pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		for ((i=1; i<=MAX_TIME_STOP; i++))
		do
			# sudo kill -SIGTERM ${pid}
			sleep 1

			kill -0  ${pid} 2>/dev/null
			live=$?
			if [ ${live} -eq 1 ]; then
				echo "stop apptable succ" | tee -a ${APPTABLE_MANAGER_LOG}
				break;
			elif [ ${i} -lt ${MAX_TIME_STOP} ]; then
				echo "stopping apptable ..." | tee -a ${APPTABLE_MANAGER_LOG}
			else
				#echo "stop apptable fail! You may be kill -9 ${pid}" | tee -a ${APPTABLE_MANAGER_LOG}
				echo "stop apptable fail! now stop apptable use kill -9 ${pid}" | tee -a ${APPTABLE_MANAGER_LOG}
				sudo kill -9 ${pid}
			fi
		done
	else
		echo "apptable not aliveing" | tee -a ${APPTABLE_MANAGER_LOG}
	fi
else
	echo "apptable not aliveing" | tee -a ${APPTABLE_MANAGER_LOG}
fi

# stop apptable_manager
pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		for ((i=1; i<=MAX_TIME_STOP; i++))
		do
			# sudo kill -SIGTERM ${pid}
			sleep 1

			kill -0  ${pid} 2>/dev/null
			live=$?
			if [ ${live} -eq 1 ]; then
				echo "stop apptable_manager succ" | tee -a ${APPTABLE_MANAGER_LOG}
				break;
			elif [ ${i} -lt ${MAX_TIME_STOP} ]; then
				echo "stopping apptable_manager ..." | tee -a ${APPTABLE_MANAGER_LOG}
			else
				#echo "stop apptable_manager fail! You may be kill -9 ${pid}" | tee -a ${APPTABLE_MANAGER_LOG}
				echo "stop apptable_manager fail! now stop apptable_manager use kill -9 ${pid}" | tee -a ${APPTABLE_MANAGER_LOG}
				sudo kill -9 ${pid}
			fi
		done
	else
		echo "apptable_manager not aliveing" | tee -a ${APPTABLE_MANAGER_LOG}
	fi
else
	if [ "$CALLER_IDENTIFY" == "restart.sh" ]; then
		echo "apptable_manager stopped in parent script 'restart.sh'" | tee -a ${APPTABLE_MANAGER_LOG}
	else	
		echo "apptable_manager not aliveing" | tee -a ${APPTABLE_MANAGER_LOG}
	fi
fi
