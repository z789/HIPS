#!/bin/bash
# =================================================================
# 脚本名称: setapptable.sh
# 被传送到即将安装apptabe的机器上执行，设置 apptable的运行环境
# 注意：在即将安装apptabe的机器上执行。所以不能source 本地的 log.sh
# 
# 注意， 在该脚本中会设置 /opt/apptable/config/config.txt 中的naming_service_url的值 
# 该值在不同的环境中需要改变
# =================================================================
#set -x

# 颜色定义 (增强生产环境的可读性)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # 无颜色

# 日志函数
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_succ() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }


LOCK_FILE="/tmp/setapptable.lock"
if [[ -f "$LOCK_FILE" ]]; then
	log_error "the script is running, and the ops exit"
	exit -1
fi
touch "$LOCK_FILE"

# 清理 
cleanup() {
	rm -f /opt/apptable/rc.local $LOCK_FILE
}
trap cleanup EXIT INT TERM

# --- 1. 系统信息提取函数 ---
get_os_info() {
    local os_file="/etc/os-release"
    local id=""
    local ver=""
    local name=""

    if [[ -f "$os_file" ]]; then
        # 提取 ID
        id=$(awk -F= '$1=="ID" {gsub(/"/, "", $2); print $2}' "$os_file")
        # 提取 VERSION_ID，如果不存在则默认为空字符串
        ver=$(awk -F= '$1=="VERSION_ID" {gsub(/"/, "", $2); print $2}' "$os_file")
        # 提取 NAME，如果不存在则默认为空字符串
        name=$(awk -F= '$1=="NAME" {gsub(/"/, "", $2); print $2}' "$os_file")
    else
        id="unknown"
        ver=""
        name=""
    fi

    # 输出以空格分隔，方便 read 接收
    echo "$id $ver $name"
}

# --- 2. 核心安装函数 ---
smart_install() {
    local pkg=$1
    local check_cmd=${2:-$pkg}

    # 获取系统信息
    read -r OS_ID OS_VER OS_NAME <<< "$(get_os_info)"

    # 1. 检查命令是否已存在
    if command -v "$check_cmd" >/dev/null 2>&1; then
        log_succ "$pkg 已经安装在系统上。"
        return 0
    fi

    # 2. 准备 sudo 权限逻辑
    local sudo_exec=""
    if [[ $EUID -ne 0 ]]; then
        sudo_exec="sudo" # 尝试交互式 sudo
    fi

    log_info "正在系统: ${OS_ID:-未知} (版本: ${OS_VER:-滚动更新}) 上安装 $pkg..."

    # 3. 跨发行版安装逻辑
    case "$OS_ID" in
        ubuntu|debian|kali|raspbian)
            eval "$sudo_exec apt-get update -qq"
            eval "$sudo_exec apt-get install -y -qq $pkg"
            ;;

        centos|rhel|rocky|almalinux|fedora)
            # 兼容旧版 CentOS 7 (yum) 和新版 Rocky/Fedora (dnf)
            local mgr="yum"
            command -v dnf >/dev/null 2>&1 && mgr="dnf"
            eval "$sudo_exec $mgr install -y -q $pkg"
            ;;

        arch|manjaro)
            # Arch Linux 核心逻辑
            eval "$sudo_exec pacman -S --noconfirm --needed $pkg"
            ;;

        *)
            log_error "暂不支持自动安装到发行版: $OS_ID"
            return 1
            ;;
    esac

    # 4. 验证安装结果
    if command -v "$check_cmd" >/dev/null 2>&1; then
        log_succ "$pkg 安装成功！"
        return 0
    else
        log_error "$pkg 安装失败，请检查网络或包名是否正确。"
        return 1
    fi
}


##  安装 apptable依赖的 tar 和 file
pkgs_to_install=("tar" "file" "sudo")
for p in "${pkgs_to_install[@]}"; do
 	smart_install "$p"
done

if [ ! -f /etc/rc.d/rc.local ]; then
	sudo cp /opt/apptable/rc.local /etc/rc.d/rc.local
fi

if [ ! -f /etc/rc.local ]; then
	ln -nfs /etc/rc.d/rc.local /etc/rc.local

	grep /opt/apptable/start.sh /etc/rc.local
	RETVAL=$?
	if [ ${RETVAL} != 0 ]; then
		grep "exit" /etc/rc.local
		RETVAL=$?
		if [ ${RETVAL} == 0 ]; then
			sudo sed --follow-symlinks -i '/exit/c\\/opt\/apptable\/start.sh\nexit 0' /etc/rc.local
		else
			sudo sed --follow-symlinks -i '$a\/opt\/apptable\/start.sh\nexit 0' /etc/rc.local
		fi
	fi

	sudo chmod +x /etc/rc.local
	sudo systemctl enable rc-local
	sudo systemctl start rc-local
else
	grep /opt/apptable/start.sh /etc/rc.local
	RETVAL=$?
	if [ ${RETVAL} != 0 ]; then
		grep "exit" /etc/rc.local
		RETVAL=$?
		if [ ${RETVAL} == 0 ]; then
			sudo sed --follow-symlinks -i '/exit/c\\/opt\/apptable\/start.sh\nexit 0' /etc/rc.local
		else
			sudo sed --follow-symlinks -i '$a\/opt\/apptable\/start.sh\nexit 0' /etc/rc.local
		fi
	fi

	if [[ ! -x /etc/rc.local ]]; then
		sudo chmod +x /etc/rc.local
	fi
fi

exit 0
