#!/bin/bash

# 在apptable_manager中调用该脚本重启时，sleep 1是为了等待父进程退出
# 并再次检查apptable_manager是否已经退出，如果没有，强制kill -9
sleep 1
pid=`pidof apptable_manager`
if [[ "${pid}" != "" ]]; then
        kill -9 ${pid} 2>/dev/null
	sleep 1
	tail --pid=${pid} -f /dev/null
fi

export CALLER_IDENTIFY="restart.sh"

DIR_INSTALL="/opt/apptable"
${DIR_INSTALL}"/stop.sh"
${DIR_INSTALL}"/start.sh"
