#!/bin/bash

DIR_INSTALL="/opt/apptable"
${DIR_INSTALL}"/stop.sh"
${DIR_INSTALL}"/start.sh"
