#!/bin/bash
 
DIR_INSTALL="/opt/apptable"
APPTABLE=${DIR_INSTALL}"/apptable"
APPTABLE_MANAGER=${DIR_INSTALL}"/apptable_manager"
DIR_APPTABLE_CONFIG=${DIR_INSTALL}"/config"
MK_USR_INTERL_NAME_LIST=${DIR_INSTALL}"/mk_usr_interp_name_list"

USR_CONFIG_FILE_LIST="${DIR_APPTABLE_CONFIG}/usr_block_hash_list ${DIR_APPTABLE_CONFIG}/usr_block_prog_list ${DIR_APPTABLE_CONFIG}/usr_block_url_list ${DIR_APPTABLE_CONFIG}/usr_block_ip_list ${DIR_APPTABLE_CONFIG}/usr_interp_name_list"

pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "apptable is aliving. If you wish restart, use ./restart.sh"
		exit 0;
	fi
fi

pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "apptable_manager is aliving. If you wish restart, use ./restart.sh"
		exit 0;
	fi
fi

for FILE in ${USR_CONFIG_FILE_LIST}
do
	if [ ! -f ${FILE} ]; then
		touch ${FILE}
		chmod 640 ${FILE}
	fi 
done


sudo ${MK_USR_INTERL_NAME_LIST}

sudo ${APPTABLE}
sleep 0.5
pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
	echo "start apptable succ"
	fi
else
	echo "start apptable fail"
	exit 1;
fi

sudo ${APPTABLE_MANAGER}
sleep 0.5
pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		echo "start apptable_manager succ"
	fi
else
	echo "start apptable_manager fail"
fi
