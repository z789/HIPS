#!/bin/bash

# stop apptable_manager
pid=`pidof apptable_manager`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		sleep 1

		kill -0  ${pid} 2>/dev/null  
		live=$?
		if [ ${live} -eq 1 ]; then
			echo "stop apptable_manager succ"
		else
			echo "stop apptable_manager fail"
		fi
	else
		echo "apptable_manager not aliveing"
	fi
else
	echo "apptable_manager not aliveing"
fi


# stop apptable
pid=`pidof apptable`
if [  "${pid}" != "" ]; then
	kill -0 ${pid} 2>/dev/null
	live=$?
	if [ ${live} -eq 0 ]; then
		sudo kill -SIGTERM ${pid}
		sleep 1

		kill -0  ${pid} 2>/dev/null  
		live=$?
		if [ ${live} -eq 1 ]; then
			echo "stop apptable succ"
		else
			echo "stop apptable fail"
		fi
	else
		echo "apptable not aliveing"
	fi
else
	echo "apptable not aliveing"
fi
